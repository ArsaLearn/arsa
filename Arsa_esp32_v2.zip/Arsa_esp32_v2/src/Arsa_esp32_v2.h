#ifndef Arsa_esp32_v2_h
#define Arsa_esp32_v2_h

#include "Print.h" 
#include <Wire.h>
#include "esp32-hal-timer.h"
#include "BluetoothSerial.h"
#include <inttypes.h>
#include "analog/analogWrite.h"
#include "neopixel/NeoPixelBus.h"
#include "neopixel/NeoPixelBrightnessBus.h"
#include "neopixel/NeoPixelAnimator.h"
#include "lcd/LiquidCrystal_I2C.h"
#include "dfplayer/DFRobotDFPlayerMini.h"
#include "sensor/Adafruit_Sensor.h"
#include <EEPROM.h>
#include "servo/Servo.h"
#include "oled1/Adafruit_GFX.h"
#include "oled/Adafruit_SSD1306.h"
#include <SPI.h>
#include "apds/Adafruit_APDS9960.h"
#include "rf/RCSwitch.h"
#include "sd/mySD.h"

#if CONFIG_FREERTOS_UNICORE
#define ARDUINO_RUNNING_CORE 0
#else
#define ARDUINO_RUNNING_CORE 1
#endif
#define low  0
#define LOW  0
#define high  255
#define HIGH  255
#define on  255
#define ON  255
#define OFF  0
#define off  0

#define cm  0
#define in  1

#define r    330
#define f    440
#define u    550
#define d    660

#define up    2
#define down  3

//==========================================================================

#define T1  203
#define T2  205
#define T3  201
#define T4  202
#define T5  204
#define T6  206

#define t1  203
#define t2  205
#define t3  201
#define t4  202
#define t5  204
#define t6  206

#define AR  219
#define SA  220
#define ar  219
#define sa  220


//==========================================================================

#define key   0

#define D1_1   1
#define D1_2   2
#define D1_3   3
#define D1_4   4
#define D1_5   5
#define D1_6   6

#define D2_1   7
#define D2_2   8
#define D2_3   9
#define D2_4   10
#define D2_5   11
#define D2_6   12

#define D3_1   13
#define D3_2   14
#define D3_3   15
#define D3_4   16
#define D3_5   17
#define D3_6   18


//==========================================================================
#define led   100
#define A1_1   101
#define A1_2   102
#define A1_3   103
#define A1_4   104
#define A1_5   105
#define A1_6   106

#define A2_1   107
#define A2_2   108
#define A2_3   109
#define A2_4   110
#define A2_5   111
#define A2_6   112

#define A3_1   113
#define A3_2   114
#define A3_3   115
#define A3_4   116
#define A3_5   117
#define A3_6   118

//==========================================

#define key   0
#define key1  3
#define key2  5
#define key3  1
#define key4  2
#define key5  4
#define key6  6

#define led   100
#define led1  103
#define led2  105
#define led3  101
#define led4  102
#define led5  104
#define led6  106

#define D   0
#define D1  3
#define D2  5
#define D3  1
#define D4  2
#define D5  4
#define D6  6

#define A  100
#define A1  103
#define A2  105
#define A3  101
#define A4  102
#define A5  104
#define A6  106

#define A   2
#define A1  14
#define A2  27
#define A3  13
#define A4  4
#define A5  33
#define A6  32

//==========================================

#define G1_1   13
#define G1_2   4
#define G1_3   14
#define G1_4   33
#define G1_5   27
#define G1_6   32

#define G2_1   16
#define G2_2   17
#define G2_3   21
#define G2_4   22
#define G2_5   21
#define G2_6   22

#define G3_1   19
#define G3_2   23
#define G3_3   18
#define G3_4   15
#define G3_5   26
#define G3_6   25

#define volt   2000
#define VOLT   2000

#define no_deb   1000
#define deb_1    1002
#define deb_2    1005
#define deb_3    1007
#define deb_4    1010
#define deb_5    1020
#define deb_6    1030
#define deb_7    1040
#define deb_8    1050
#define deb_9    1080
#define deb_10   1100
//====================spk======================

#define NOTE_B0  31
#define NOTE_C1  33
#define NOTE_CS1 35
#define NOTE_D1  37
#define NOTE_DS1 39
#define NOTE_E1  41
#define NOTE_F1  44
#define NOTE_FS1 46
#define NOTE_G1  49
#define NOTE_GS1 52
#define NOTE_A1  55
#define NOTE_AS1 58
#define NOTE_B1  62
#define NOTE_C2  65
#define NOTE_CS2 69
#define NOTE_D2  73
#define NOTE_DS2 78
#define NOTE_E2  82
#define NOTE_F2  87
#define NOTE_FS2 93
#define NOTE_G2  98
#define NOTE_GS2 104
#define NOTE_A2  110
#define NOTE_AS2 117
#define NOTE_B2  123
#define NOTE_C3  131
#define NOTE_CS3 139
#define NOTE_D3  147
#define NOTE_DS3 156
#define NOTE_E3  165
#define NOTE_F3  175
#define NOTE_FS3 185
#define NOTE_G3  196
#define NOTE_GS3 208
#define NOTE_A3  220
#define NOTE_AS3 233
#define NOTE_B3  247
#define NOTE_C4  262
#define NOTE_CS4 277
#define NOTE_D4  294
#define NOTE_DS4 311
#define NOTE_E4  330
#define NOTE_F4  349
#define NOTE_FS4 370
#define NOTE_G4  392
#define NOTE_GS4 415
#define NOTE_A4  440
#define NOTE_AS4 466
#define NOTE_B4  494
#define NOTE_C5  523
#define NOTE_CS5 554
#define NOTE_D5  587
#define NOTE_DS5 622
#define NOTE_E5  659
#define NOTE_F5  698
#define NOTE_FS5 740
#define NOTE_G5  784
#define NOTE_GS5 831
#define NOTE_A5  880
#define NOTE_AS5 932
#define NOTE_B5  988
#define NOTE_C6  1047
#define NOTE_CS6 1109
#define NOTE_D6  1175
#define NOTE_DS6 1245
#define NOTE_E6  1319
#define NOTE_F6  1397
#define NOTE_FS6 1480
#define NOTE_G6  1568
#define NOTE_GS6 1661
#define NOTE_A6  1760
#define NOTE_AS6 1865
#define NOTE_B6  1976
#define NOTE_C7  2093
#define NOTE_CS7 2217
#define NOTE_D7  2349
#define NOTE_DS7 2489
#define NOTE_E7  2637
#define NOTE_F7  2794
#define NOTE_FS7 2960
#define NOTE_G7  3136
#define NOTE_GS7 3322
#define NOTE_A7  3520
#define NOTE_AS7 3729
#define NOTE_B7  3951
#define NOTE_C8  4186
#define NOTE_CS8 4435
#define NOTE_D8  4699
#define NOTE_DS8 4978
#define TONE_CHANNEL 0

int ws_2812 (uint8_t pin_number, uint8_t red , uint8_t gren , uint8_t blue);


void spk(uint8_t pin, unsigned int frequency, unsigned long duration = 0, uint8_t channel = TONE_CHANNEL);
void nospk(uint8_t pin, uint8_t channel = TONE_CHANNEL);
 int GetKeys();
int key_pad(uint8_t piin_key , uint8_t piin_clokc);
void pin (int pin_number ,void* arg, int mode);
int  pin (int pin_number , int Value );
int  pin (int pin_number);
void pin(void);
// int pin_av (int pin_number,int av_number);

void bt_name(String name="Arsalearn");
int bt_read(void);
int bt_av(void);
void bt_read_data(void);
int bt_pin(void);
int bt_data(void);
int bt_data1(void);
int bt_data2(void);
int bt_data3(void);
int bt_mode(void);
int bt_menu(void);
int bt_game(void);
int  tred(void);
void help(void);
void run();

#ifndef CORE_CORE_FUNCTIONALINTERRUPT_H_
#define CORE_CORE_FUNCTIONALINTERRUPT_H_

#include <functional>

struct InterruptArgStructure {
	std::function<void(void)> interruptFunction;
};

void pin(uint8_t pin, std::function<void(void)> intRoutine, int mode);

#endif /* CORE_CORE_FUNCTIONALINTERRUPT_H_ */
#endif



#ifndef MAIN_ESP32_HAL_TIMER_H_
#define MAIN_ESP32_HAL_TIMER_H_

#ifdef __cplusplus
extern "C" {
#endif

#include "esp32-hal.h"
#include "freertos/FreeRTOS.h"

struct hw_timer_s;
typedef struct hw_timer_s hw_timer_t;

hw_timer_t * timerBegin(uint8_t timer, uint16_t divider, bool countUp);
void timerEnd(hw_timer_t *timer);

void timerSetConfig(hw_timer_t *timer, uint32_t config);
uint32_t timerGetConfig(hw_timer_t *timer);

void timerAttachInterrupt(hw_timer_t *timer, void (*fn)(void), bool edge);
void timerDetachInterrupt(hw_timer_t *timer);

void timerStart(hw_timer_t *timer);
void timerStop(hw_timer_t *timer);
void timerRestart(hw_timer_t *timer);
void timerWrite(hw_timer_t *timer, uint64_t val);
void timerSetDivider(hw_timer_t *timer, uint16_t divider);
void timerSetCountUp(hw_timer_t *timer, bool countUp);
void timerSetAutoReload(hw_timer_t *timer, bool autoreload);

bool timerStarted(hw_timer_t *timer);
uint64_t timerRead(hw_timer_t *timer);
uint64_t timerReadMicros(hw_timer_t *timer);
double timerReadSeconds(hw_timer_t *timer);
uint16_t timerGetDivider(hw_timer_t *timer);
bool timerGetCountUp(hw_timer_t *timer);
bool timerGetAutoReload(hw_timer_t *timer);

void timerAlarmEnable(hw_timer_t *timer);
void timerAlarmDisable(hw_timer_t *timer);
void timerAlarmWrite(hw_timer_t *timer, uint64_t interruptAt, bool autoreload);

bool timerAlarmEnabled(hw_timer_t *timer);
uint64_t timerAlarmRead(hw_timer_t *timer);
uint64_t timerAlarmReadMicros(hw_timer_t *timer);
double timerAlarmReadSeconds(hw_timer_t *timer);


#ifdef __cplusplus
}
#endif

#endif /* MAIN_ESP32_HAL_TIMER_H_ */

void timer_on(int number, void (*fn)(void), float time,int Frequency, bool edge);
void timer_off(void);

int ultrasonic(int echo_pin, int trigger_pin, bool out_mode=0);


#include "Arsa_esp32_v2.h"
#include <inttypes.h>
#include "esp32-hal-timer.h"
#include "analog/analogWrite.h"
#include "neopixel/NeoPixelBus.h"
#include "neopixel/NeoPixelBrightnessBus.h"
#include "neopixel/NeoPixelAnimator.h"
#include "lcd/LiquidCrystal_I2C.h"
#include "dfplayer/DFRobotDFPlayerMini.h"
#include "sensor/Adafruit_Sensor.h"
#include <EEPROM.h>
#include "servo/Servo.h"
#include "oled1/Adafruit_GFX.h"
#include <SPI.h>
#include "oled/Adafruit_SSD1306.h"
#include "apds/Adafruit_APDS9960.h"
#include "rf/RCSwitch.h"
#include "sd/mySD.h"

//----------------------------------------تعریف پایه ها -----------------------------------
//=====================GENERAL=====================


//==================================پایه های ورودی  برد برد ===============================
uint8_t li_name_pin[] = {2,13,4,14,33,27,32,16,17,21,22,21,22,19,23,18,15,26,25};
//==================================پایه های برد ماِژول ها =================================
uint8_t li_name_pin_in[] = {0,13,4,14,33,27,32,16,17,21,22,21,22,19,23,18,15,26,25,12,15};
//===========================================================================================
uint8_t li_size_touch[]  = {0,0,0,0,0,0,0};
//×××××××××××××××××××××××××××××××××××××××××××××××××××××××××××××××××××××××××××××××××××××××××××
 hw_timer_t * timer = NULL;

int _q=0;
bool enter_help_pin=0,enter_help_press = 0;

BluetoothSerial SerialBT; //فراخوانی بلوتوث 

//----------------------------------------تابع touch ------------------------------------------
int touchRead_av(int pin_number)
{
    int AVRE=0;
    pin_number = li_name_pin_in[pin_number];
    AVRE = 0;
    for (byte i = 0; i < 10; i++)
    {
      AVRE += touchRead(pin_number);
      delay(1);
    }
    return AVRE / 10;
}
//××××××××××××××××××××××××××××××××××××××××××××××××××××××××××××××××××××××××××××××××××××××××××××××

//----------------------------------------تابع کي پد-------------------------------------------
int _piin_clokc;
int _piin_key;
int key_pad(uint8_t piin_key , uint8_t piin_clokc)
{
_piin_clokc =  li_name_pin[piin_clokc];
      _piin_key =  li_name_pin[piin_key];
  pinMode(_piin_key, INPUT);
  pinMode(_piin_clokc, OUTPUT);
  unsigned int keyss = 0;
  byte currbit = LOW;
  delay(3);
  for (byte i = 1; i < 17; i++)
  {
    digitalWrite(_piin_clokc, HIGH);
    delayMicroseconds(10);
    digitalWrite(_piin_clokc, LOW);
    delayMicroseconds(10);
    currbit = digitalRead(_piin_key);
    if (currbit == LOW) return i; //= If active High is set. Otherwise, invert the test
  }
  return 0;
}
//××××××××××××××××××××××××××××××××××××××××××××××××××××××××××××××××××××××××××××××××××××××××××××××

//-----------------------------------------تابع spk -------------------------------------------
void spk(uint8_t pin, unsigned int frequency, unsigned long duration, uint8_t channel)
{
pin =  li_name_pin[pin];
    if (ledcRead(channel)) {
        log_e("Tone channel %d is already in use", ledcRead(channel));
        return;
    }
    ledcAttachPin(pin, channel);
    ledcWriteTone(channel, frequency);
    if (duration) {
        delay(duration);
        nospk(pin, channel);
    }    
}
//××××××××××××××××××××××××××××××××××××××××××××××××××××××××××××××××××××××××××××××××××××××××××××××

//----------------------------------------خاموش کردن ------------------------------------------
void nospk(uint8_t pin, uint8_t channel)
{
    ledcDetachPin(pin);
    ledcWrite(channel, 0);
}
//××××××××××××××××××××××××××××××××××××××××××××××××××××××××××××××××××××××××××××××××××××××××××××××

// ----------------------------------------pinتوبع---------------------------------------------
//======================================تابع غلط pin===========================================
void pin(void)
{
    if(enter_help_pin == 0)
    {
        Serial.println("                    بدون مقدار                     ");
        Serial.println("       براي خواندن ورودي شماره پايه را در پرانتز قرار دهيد     ");
        Serial.println("براي دستور دادن به پايه, شماره پايه و دستور را به صورت زير بنويسيد");
        Serial.println("                pin(دستور , شماره پايه);             ");
        enter_help_pin = 1;
    }
}
//===============================تابع خواندن مقدار پايه ها===================================

int pin (int pin_number)
{
  //=================================خواندن دیجیتال usb=======================================
  if(pin_number < 100)
  {
      pin_number =  li_name_pin_in[pin_number];
      pinMode(pin_number ,INPUT_PULLUP);
      
        if(digitalRead(pin_number)==0)
        {
           delay(1);
          if(digitalRead(pin_number)==0)
          {
             if(_q == 0)
             {
                 _q = 1;
                 return 2;
             }else return 1;
          }
        }
      
      else if (digitalRead(pin_number)==1)
      {
       delay(1);

        if(digitalRead(pin_number)==1)
        {
              if(_q == 1)
              {
                  _q = 0;
                  return 3;
              }else return 0;
        }
        
      }
  }
  
 else if(pin_number<200)
 {
      pin_number = pin_number - 100;
      pin_number =  li_name_pin[pin_number];
      pinMode(pin_number ,INPUT);
      return  analogRead(pin_number);
 }
  //=====  
   
  else if(pin_number < 300)
  {
      pin_number = pin_number - 200;
      int pin_num = pin_number;
      pin_number =  li_name_pin_in[pin_number];
      pinMode(pin_number ,INPUT);
      if(touchRead_av(pin_num) < li_size_touch[pin_num]-2)return 1;
      return 0;
  }

}
int pin (int pin_number , int Value)
{
    if(Value > 1900)
    {
            if(pin_number < 100)
            {int AVRE;
                pin_number =  li_name_pin_in[pin_number];
                pinMode(pin_number ,INPUT);
                    AVRE = analogRead(pin_number);
                    AVRE = AVRE/4095;
                    AVRE = AVRE*3300;
                return AVRE;
            }else if(pin_number<200)
            {
                int AVRE;
                pin_number = pin_number - 100;
                pin_number =  li_name_pin_in[pin_number];
                pinMode(pin_number ,INPUT);
                AVRE = analogRead(pin_number);
                AVRE = AVRE/4095;
                AVRE = AVRE*3300;
                return AVRE;
            }else if(pin_number < 300)
            {
                int AVRE;
                pin_number = pin_number - 200;
                pin_number =  li_name_pin_in[pin_number];
                pinMode(pin_number ,INPUT);
                AVRE = analogRead(pin_number);
                AVRE = AVRE/4095;
                AVRE = AVRE*3300;
                return AVRE;
            }
    }

    else if(Value >= 1000)
    {
            Value = Value - 1000;
        if(pin_number < 100)
        {
                    Value = Value * 10;
            pin_number =  li_name_pin_in[pin_number];
            pinMode(pin_number ,INPUT_PULLUP);

                if(digitalRead(pin_number)==0)
                {
                delay(Value);
                if(digitalRead(pin_number)==0)
                {
                    if(_q == 0)
                    {
                        _q = 1;
                        return 2;
                    }else return 1;
                }
                }

            else if (digitalRead(pin_number)==1)
            {
            delay(Value);

                if(digitalRead(pin_number)==1)
                {
                    if(_q == 1)
                    {
                        _q = 0;
                        return 3;
                    }else return 0;
                }

            }
        }

        else if(pin_number<200)
        {
            int AVRE=0;
            pin_number = pin_number - 100;
            pin_number =  li_name_pin[pin_number];
            pinMode(pin_number ,INPUT);
            AVRE = 0;
            for (byte i = 0; i < Value; i++)
            {
                AVRE += analogRead(pin_number);
                delay(1);
            }
            return AVRE / Value;
        }
        //=====
        
        else if(pin_number < 300)
        {
            pin_number = pin_number - 200;
            int pin_num = pin_number;
            pin_number =  li_name_pin_in[pin_number];
            pinMode(pin_number ,INPUT);
            if(touchRead_av(pin_num) < li_size_touch[pin_num]-Value)return 1;
            return 0;
        }
        }
        
        else
        {
         if(pin_number < 100)
            {
              pin_number =  li_name_pin[pin_number];
                pinMode(pin_number ,OUTPUT);
                digitalWrite(pin_number , Value);
            }else if(pin_number < 200)
            {
                pin_number = pin_number - 100;
                pin_number =  li_name_pin[pin_number];
                pinMode(pin_number ,OUTPUT);
                analogWrite(pin_number , Value);
            }
        }
}

//****************************************************************************************************************************

int ws_2812 (uint8_t pin_number , uint8_t red , uint8_t gren , uint8_t blue)
{
pin_number = pin_number - 100;
pin_number =  li_name_pin[pin_number];
NeoPixelBus<NeoGrbFeature, Neo800KbpsMethod> strip(1, pin_number);
RgbColor demo(red, gren, blue);
strip.Begin();
strip.Show();
strip.SetPixelColor(0, demo);
strip.Show();

}
//****************************************************************************************************************************

//------------------------------------------تابع run--------------------------------------------
void run()
{
  Serial.begin(115200);

  li_size_touch[1] = touchRead_av(1);
  li_size_touch[2] = touchRead_av(2);
  li_size_touch[3] = touchRead_av(3);
  li_size_touch[4] = touchRead_av(4);
  li_size_touch[5] = touchRead_av(5);
  li_size_touch[6] = touchRead_av(6);
Serial.println("");
Serial.println("");
Serial.println("╔════════════════════════════════════════════════════════════════════════════════════╗");
Serial.println("                                                               شماره پایه های مین ورژن 2");
Serial.println("");
Serial.println("                                                            ╔══════▀▀▀▀▀══════╗");
Serial.println("                       G1_6-G1_5   G1_4-G1_3   G1_2-G1_1    ‖                              ‖ G2_1-G2_2   G2_3-G2_4   G2_5-G2_6");
Serial.println("                     ╔══▀▀▀════▀▀▀════▀▀▀═══╣                             ╠══▀▀▀════▀▀▀════▀▀▀═══╗");
Serial.println("                     ╚══════════════════════╣                             ╠══════════════════════╝");
Serial.println("                                 PORT 1 (TUCH)              ‖                              ‖               ( PORT 2 )");
Serial.println("                                                            ‖                              ‖");
Serial.println("                                                            ‖     (( Arsa_esp32_v2 ))      ‖");
Serial.println("                                                            ‖                              ‖");
Serial.println("                                                            ‖                              ‖");
Serial.println("                     ╔══════════════════════╣                             ╠══════════════════════╗");
Serial.println("                     ╚══════════════════════╣                             ╠══▀▀▀════▀▀▀════▀▀▀═══╝");
Serial.println("                              (Power &&  Programer)         ‖                              ‖  G3_1-G3_2   G3_3-G3_4   G3_5-G3_6");
Serial.println("                                                            ╚════════█════════╝               ( PORT 3 )");
Serial.println("");
Serial.println("");
Serial.println("╚════════════════════════════════════════════════════════════════════════════════════╝");
Serial.println("");
Serial.println("");
Serial.println("╔════════════════════════════════════════════════════════════════════════════════════╗");
Serial.println("                                                                شماره پایه های برد برد");
Serial.println("                                                                        ╔═══╗");
Serial.println("                                                                        |      |");
Serial.println("                                                                        |      |");
Serial.println("                                                    ╔═══════════╝     ╚═══════════╗");
Serial.println("                                                    |                                               |");
Serial.println("                                                    |              ((  bred bord  ))                |");
Serial.println("                                                    |                                               |");
Serial.println("                                                    ╚╤═╤═╤═╤═╤═╤═╤═╤═╤═╤═╤═╤═╤═╤╝");
Serial.println("                                                      -  G6  +  G5  -  G4  +  G3 -  G2  +  G1  -  5v");
Serial.println("");
Serial.println("╚════════════════════════════════════════════════════════════════════════════════════╝");

}

//**********************************************************************************************

//-----------------------------------------تابع tr --------------------------------------------
int  tred(void)
{

}
//××××××××××××××××××××××××××××××××××××××××××××××××××××××××××××××××××××××××××××××××××××××××××××××
//----------------------------------------توابع بلوتوث-----------------------------------------
int  li_menu,li_mode;
int  li_size_data;
int  li_data_1,li_data_2,li_data_3;
int  li_pin = 0;
int  pin_num_copy = 0;
void bt_name(String name)
{
    #if !defined(CONFIG_BT_ENABLED) || !defined(CONFIG_BLUEDROID_ENABLED)
    #error Bluetooth is not enabled! Please run `make menuconfig` to and enable it
    #endif

    SerialBT.begin(name); //Bluetooth device name
}
int bt_read(void)
{
    return SerialBT.read();
}
int bt_av(void)
{
    return SerialBT.available();
}
void bt_read_data(void)
{
   int i=0;
   int  data_bt[10];
   while(SerialBT.available())
    {
        data_bt[i] = SerialBT.read();
        i++;
        if(i >8)break;
    }
    if(data_bt[0] == 255)
    {
        li_menu       = data_bt[1];
        li_mode       = data_bt[2];
        li_size_data  = data_bt[4];
        li_data_1     = data_bt[5];
        li_data_2     = data_bt[3];
        li_data_3     = data_bt[6];
        if(li_size_data > 1)
        {
            li_data_1 = data_bt[6] + li_data_1 * 255;
        }
        if((li_menu == 10)&&(li_mode == 1))
        {
            li_pin = data_bt[5]+100;
            li_data_1 = 0;
        }else li_pin = 0;
    }
}
int bt_pin(void)
{
    bt_read_data();
    if(li_pin != 0) pin_num_copy = li_pin;
    return pin_num_copy;
}
int bt_data(void)
{
    bt_read_data();
    return li_data_1;
}
int bt_data1(void)
{
    bt_read_data();
    return li_data_2;
}
int bt_data2(void)
{
    bt_read_data();
    return li_data_3;
}
int bt_data3(void)
{
    bt_read_data();
    return li_size_data;
}
int bt_mode(void)
{
    bt_read_data();
    return li_mode;
}
int bt_menu(void)
{
    bt_read_data();
    return li_menu;
}
int bt_game(void)
{
   bt_read_data();
     if ((li_data_2 == 1) && (li_size_data == 2) && (li_menu == 1) && (li_mode == 1) && (li_data_1!= 0)) {
      return li_data_1;
    }
    else if ((li_data_2 == 1) && (li_size_data == 2) && (li_menu== 1) && (li_mode == 2) && (li_data_1 != 0)) {
      return li_data_1;
    }
    else if ((li_data_2 == 1) && (li_size_data == 2) && (li_menu == 1) && (li_mode == 3) && (li_data_1!= 0)) {
          return li_data_1;
    }   
}

//**********************************************************************************************

#include "FunctionalInterrupt.h"
#include "Arduino.h"

typedef void (*voidFuncPtr)(void);
typedef void (*voidFuncPtrArg)(void*);

extern "C"
{
	extern void __attachInterruptFunctionalArg(uint8_t pin, voidFuncPtrArg userFunc, void * arg, int intr_type, bool functional);
}

void IRAM_ATTR interruptFunctional(void* arg)
{
    InterruptArgStructure* localArg = (InterruptArgStructure*)arg;
	if (localArg->interruptFunction)
	{
	  localArg->interruptFunction();
	}
}

void pin(uint8_t pin, std::function<void(void)> intRoutine, int mode)
{
  pin =  li_name_pin_in[pin];
	// use the local interrupt routine which takes the ArgStructure as argument
	__attachInterruptFunctionalArg (pin, (voidFuncPtrArg)interruptFunctional, new InterruptArgStructure{intRoutine}, mode, true);
}

extern "C"
{
   void cleanupFunctional(void* arg)
   {
	 delete (InterruptArgStructure*)arg;
   }
}

//**********************************************************************************************


void timer_on(int number, void (*fn)(void), float time,int Frequency, bool edge)
{
      timer = timerBegin(number, Frequency, edge);
  timerAttachInterrupt(timer, fn, edge);
  timerAlarmWrite(timer, time, edge);
  timerAlarmEnable(timer);
}

void timer_off(void)
{
   timerAlarmDisable(timer);		// stop alarm
        timerDetachInterrupt(timer);	// detach interrupt
        timerEnd(timer);			// end timer
}

int ultrasonic(int echo_pin, int trigger_pin, bool out_mode)
{
  trigger_pin =  li_name_pin[trigger_pin];
    echo_pin =  li_name_pin[echo_pin];

  pinMode(trigger_pin, OUTPUT);
  pinMode(echo_pin, INPUT);

  digitalWrite(trigger_pin, 1);
  delayMicroseconds(2);
  digitalWrite(trigger_pin, 0);
  delayMicroseconds(10);
  digitalWrite(trigger_pin, 1);
  int time = pulseIn(echo_pin, 1);

  if(out_mode==1) return time / 74 / 2;
 else if(out_mode==0) return time / 29 / 2;
return time / 29 / 2;
}